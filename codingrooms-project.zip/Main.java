import java.util.*;
import java.util.Scanner;
public class Main {

   public static void main(String[] args) {
      Scanner scnr = new Scanner(System.in);
      int num;
      int count;
      System.out.println("Please enter an integer");
      num = scnr.nextInt();
      for(count = 0; count < 21; ++count) {
        System.out.println(num + " x " + count + " = " + (count * num));
      }
   }
}